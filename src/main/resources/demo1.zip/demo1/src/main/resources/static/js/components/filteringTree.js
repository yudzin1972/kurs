webix.ready(function(){
webix.ui({
  height:400,
  width:800,
  padding:15,
  margin:10,
  container: "app",
  id: "myRoot",
  cols:[
    {rows:[
      {
        view:"text",
        label:"Filter on all levels, show children",
        labelPosition:"top"
      },
      {
        view:"tree", borderless:true,
        id:"tree1",
        select:true,
        data: webix.copy(carsdata)
      }
    ]},
    {rows:[
      {
        view:"text",
        label:"Filter on all levels, strict",
        labelPosition:"top"
      },
      {
        view:"tree", borderless:true,
        id:"tree2",
        filterMode:{
          showSubItems:false
        },
        select:true,
        data: webix.copy(carsdata)
      }
    ]},
    {rows:[
      {
        view:"text",
        label:"Filter items on 2rd level only",
        labelPosition:"top"
      },
      {
        view:"tree", borderless:true,
        id:"tree3",
        filterMode:{
          showSubItems:false,
          level:2
        },
        select:true,
        data: webix.copy(carsdata)
      }
    ]}
  ]
});


$$("$text1").attachEvent("onTimedKeyPress",function(){
  $$("tree1").filter("#value#",this.getValue());
});
$$("$text2").attachEvent("onTimedKeyPress",function(){
  $$("tree2").filter("#value#",this.getValue());
});
$$("$text3").attachEvent("onTimedKeyPress",function(){
  $$("tree3").filter("#value#",this.getValue());
})

});