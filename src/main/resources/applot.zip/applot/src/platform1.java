import lotus.domino.*;
public class platform1 extends NotesThread
{
  public static void main(String argv[])
    {
        platform1 t = new platform1();
        t.start();
    }
  public void runNotes()
    {
    try
      {
        Session s = NotesFactory.createSession();
        // To bypass Readers fields restrictions
        // Session s = NotesFactory.createSessionWithFullAccess();
        String p = s.getPlatform();
        System.out.println("Platform = " + p);
      }
    catch (Exception e)
      {
        e.printStackTrace();
      }
    }
}