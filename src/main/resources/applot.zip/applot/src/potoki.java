public class potoki {
    public static void main(String args[]) {

        // This is the first block of code
        Thread thread = new Thread() {
            public void run() {
                for ( int i = 0; i < 100000; i ++) {
                    System.out.println("hello this is thread one"+String.valueOf(i));
                }
            }
        };

        // This is the second block of code
        Thread threadTwo = new Thread() {
            public void run() {
                for (int i = 0; i < 100000; i ++) {
                    System.out.println("hello this is thread two"+String.valueOf(i));
                }
            }
        };
        Thread thread3 = new Thread() {
            public void run() {
                for (int i = 0; i < 100000; i ++) {
                    System.out.println("hello this is thread 3 "+String.valueOf(i));
                }
            }
        };
        // These two statements are in the main method and begin the two
        // threads.
        // This is the third block of code
        thread.start();

        // This is the fourth block of code
        threadTwo.start();
        thread3.start();
    }
}